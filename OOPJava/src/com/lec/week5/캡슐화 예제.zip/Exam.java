package com.lec.week5;

public class Exam {
	
	int kor;
	int eng;
	int math;
}
